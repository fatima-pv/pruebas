package org.e2e.auth.dto;

import lombok.Data;

@Data
public class AuthResponseDto {
    private String token;
}
