package org.e2e.coordinate.dto;

import lombok.Data;

@Data
public class CoordinateDto {
    private Double latitude;
    private Double longitude;
}
