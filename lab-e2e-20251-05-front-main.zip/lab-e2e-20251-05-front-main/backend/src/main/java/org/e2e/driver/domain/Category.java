package org.e2e.driver.domain;

public enum Category {
    X,XL,BLACK
}
