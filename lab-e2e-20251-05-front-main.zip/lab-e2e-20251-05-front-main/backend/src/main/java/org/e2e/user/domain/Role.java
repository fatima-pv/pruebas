package org.e2e.user.domain;

public enum Role {
    ADMIN,PASSENGER, DRIVER
}
