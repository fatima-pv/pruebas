package org.e2e.websocket;

public enum DriverAnswer {
    PENDING, ACCEPTED, REJECTED
}
