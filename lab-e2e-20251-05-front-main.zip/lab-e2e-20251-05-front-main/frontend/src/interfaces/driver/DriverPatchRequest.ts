export interface DriverPatchRequest {
    firstName: string;
    lastName: string;
    phoneNumber: string;
}
