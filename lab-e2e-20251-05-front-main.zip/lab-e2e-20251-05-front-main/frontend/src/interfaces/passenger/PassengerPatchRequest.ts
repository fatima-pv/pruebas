export interface PassengerPatchRequest {
    firstName: string;
    lastName: string;
    phoneNumber: string;
}
