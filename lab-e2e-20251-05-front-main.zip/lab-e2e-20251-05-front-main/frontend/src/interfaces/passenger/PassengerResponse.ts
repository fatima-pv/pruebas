export interface PassengerResponse {
    firstName: string;
    lastName: string;
    phoneNumber: string;
    avgRating: number;
}
