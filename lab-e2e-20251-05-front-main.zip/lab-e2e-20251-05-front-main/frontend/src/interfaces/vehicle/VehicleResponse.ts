export interface VehicleResponse {
    brand: string;
    model: string;
    licensePlate: string;
    fabricationYear: number;
    capacity: number;
}
