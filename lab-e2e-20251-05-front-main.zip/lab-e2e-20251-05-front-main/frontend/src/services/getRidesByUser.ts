import { PaginatedRequest } from "@interfaces/pagination/PaginatedRequest";

export async function getRidesByUser(paginatedRequest: PaginatedRequest) {}
