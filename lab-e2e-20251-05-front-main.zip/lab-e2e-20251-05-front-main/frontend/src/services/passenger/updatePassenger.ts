import { PassengerPatchRequest } from "@interfaces/passenger/PassengerPatchRequest";

export async function updatePassenger(
	passengerPatchRequest: PassengerPatchRequest,
) {}
